package folder;
public class MainFunction {
    public static void main(String[] args)
    {
        System.out.println("connected");
        Home_page obn = new Home_page();
        obn.setVisible(true);
    }
}
